package br.com.stayaway.hotel.model;

public enum tipoAdicional {

    SERVICO, ITEM;

}
